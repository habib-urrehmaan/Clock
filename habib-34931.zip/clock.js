function draw()
{
	var canvas=document.getElementById("clock");
	var context=canvas.getContext("2d");
	context.clearRect(0,0,300,300);
	DrawClock(context);
	drawNumbers(context);
	drawTime(context);
}

function DrawClock(ctx)
{
  ctx.beginPath();
ctx.arc(150,150,129,0,Math.PI*2);
 ctx.stroke();
 
  ctx.save();
 ctx.translate(150,150);
	

}

function drawNumbers(ctx) {
       for (i=1;i<=60;i++) {
 ang=Math.PI/30*i;
 sang=Math.sin(ang);
 cang=Math.cos(ang);

    if (i % 5 == 0) {
            ctx.lineWidth=8;
 
             sx=sang*95;
             sy=cang*-95;
             ex=sang*120;
             ey=cang*-120;
             nx=sang*80;
             ny=cang*-80;
             ctx.fillText(i/5,nx,ny);
           
           } else {
             ctx.lineWidth=2;
             sx=sang*110;
             sy=cang*110;
             ex=sang*120;
             ey=cang*120;
           }
           ctx.beginPath();
           ctx.moveTo(sx,sy);
 ctx.lineTo(ex,ey);
 ctx.stroke();

 }
    }

function drawTime(ctx){
 var now=new Date();
var hrs=now.getHours();
 var min=now.getMinutes();
 var sec=now.getSeconds();

//hour hand
 ctx.rotate(Math.PI/6*(hrs+(min/60)+(sec/3600)));
 ctx.beginPath();
 ctx.moveTo(0,10);
 ctx.lineTo(0,-60);
 ctx.stroke();
 //ctx.save();
 

 //minute hand
 ctx.rotate(Math.PI/30*(min+(sec/60)));
 ctx.beginPath();
 ctx.moveTo(0,20);
 ctx.lineTo(0,-110);
 ctx.stroke();
ctx.save();

 //second hand
 ctx.rotate(Math.PI/30*sec);
ctx.strokeStyle="#E33";
ctx.beginPath();
ctx.moveTo(0,20);
ctx.lineTo(0,-110);
ctx.stroke();
ctx.restore();
ctx.restore();
setTimeout(draw,1000);

}

window.onload=draw;